#Math Moves

##Description

A mental math game where your sprite tries to reach a certain number(the goal) 
in x amount of steps. You must be plus or minus 10 from the goal. 

Once the sprite hits the chosen block the operation will be applied to the numbers

The block has a 50 50 chance of disappearing or turning into a question block

If you hit the question block there is a 1 in 4 chance of getting any of the operations

##Rules

1. Entering the game a goal and moves will be generated. Press enter to start
2. random numbers will be generated for the sprite to apply the operations to
3. move left and right with the arrow keys and use space to jump
4. hit the operation of your choice. There is no going back after you hit it
5. be within +-10 of the goal to attain Victory
6. Good luck!